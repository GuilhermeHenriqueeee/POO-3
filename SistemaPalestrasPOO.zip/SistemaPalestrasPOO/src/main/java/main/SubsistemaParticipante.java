/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package main;

/**
 *
 * @author guilh
 */
public class SubsistemaParticipante {

    public static void main(String[] args) {
        EscolherEntrada escolher = new EscolherEntrada();
    }
}
